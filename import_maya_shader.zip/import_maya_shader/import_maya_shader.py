import bpy
import json
import os
import re

#
# 1) Map Arnold Attributes -> Blender 4.3 Principled BSDF socket indices
#
PRINCIPLED_43_SOCKET_MAP = {
    "baseColor": 0,
    "metalness": 1,
    "specularRoughness": 2,
    "subsurface": 7,
    "subsurfaceColor": 8,
    "transmission": 17,
    "emissionColor": 26,
    "coat": 18,
    "coatRoughness": 19,
}


def set_udim(image, file_path):
    """
    Detect and set UDIM texture paths in Blender.
    """
    dot_pattern = re.sub(r'\.(\d{4})(\.\w+)$', r'.<UDIM>\2', file_path)
    under_pattern = re.sub(r'_(\d{4})(\.\w+)$', r'_<UDIM>\2', file_path)

    if dot_pattern != file_path:
        image.filepath = dot_pattern
        image.source = 'TILED'
    elif under_pattern != file_path:
        image.filepath = under_pattern
        image.source = 'TILED'


def set_principled_value(attr, val, principled_node):
    """
    Assigns a numeric or color value to the Principled BSDF node.
    Ensures proper conversion of float vs. color values.
    """
    if attr not in PRINCIPLED_43_SOCKET_MAP:
        return False

    socket_index = PRINCIPLED_43_SOCKET_MAP[attr]
    target_socket = principled_node.inputs[socket_index]

    # Blender expects specific types for float and color inputs
    try:
        if isinstance(target_socket.default_value, float):
            # Expecting a float: convert from list/tuple if needed
            if isinstance(val, (list, tuple)) and len(val) > 0:
                target_socket.default_value = float(val[0])  # Use first value
            else:
                target_socket.default_value = float(val)
        
        elif isinstance(target_socket.default_value, (list, tuple)):
            # Expecting a color (RGBA): ensure we pass exactly 4 values
            if isinstance(val, (list, tuple)) and len(val) == 3:
                target_socket.default_value = (val[0], val[1], val[2], 1.0)  # Add alpha=1
            else:
                print(f"[WARNING] '{attr}' expected a 3-float list, but got '{val}'. Skipping.")
                return False

        print(f"[DEBUG] Set '{attr}' to {target_socket.default_value}")
        return True

    except Exception as e:
        print(f"[ERROR] Could not set '{attr}': {e}")
        return False



def recursive_organize(current_node, level, offset):
    """
    Organizes the shader nodes in a clean layout.
    """
    next_level = level + 1
    y_level = -1
    node_above = None

    for node_input in current_node.inputs:
        for link in node_input.links:
            y_level += 1
            from_node = link.from_node

            node_above_height = 0
            if node_above:
                node_above_height = node_above.height

            from_node.location.x = current_node.location.x - (current_node.width + from_node.width * 2) - offset
            from_node.location.y = current_node.location.y - node_above_height - (y_level * offset)

            node_above = from_node
            recursive_organize(from_node, next_level, offset)


def organize_nodes(node_tree, output_node):
    offset = 200
    recursive_organize(output_node, 0, offset)


def import_ai_standard_surface_data(json_path):
    print(f"[INFO] Loading JSON from {json_path}")

    if not os.path.exists(json_path):
        print(f"[ERROR] JSON file does not exist: {json_path}")
        return

    with open(json_path, "r") as f:
        data = json.load(f)

    # Extract meshes and shaders from JSON
    meshes_data = data.get("meshes", {})
    shaders_data = data.get("shaders", {})

    print(f"[INFO] Found {len(meshes_data)} meshes and {len(shaders_data)} shaders.")

    for mesh_name, mesh_data in meshes_data.items():
        transform_name = mesh_data.get("transform")
        if not transform_name:
            print(f"[WARNING] No transform name for mesh '{mesh_name}', skipping.")
            continue

        transform_name_clean = transform_name.split('|')[-1]
        print(f"\n[INFO] Looking for Blender object '{transform_name_clean}'")

        transform_obj = bpy.data.objects.get(transform_name_clean)
        if not transform_obj:
            print(f"[WARNING] Object '{transform_name_clean}' not found, skipping.")
            continue
        elif transform_obj.type != 'MESH':
            print(f"[WARNING] '{transform_name_clean}' is not a MESH, skipping.")
            continue

        print(f"[INFO] Found mesh: {transform_name_clean}. Clearing existing materials...")
        transform_obj.data.materials.clear()

        #
        # Process each assigned shader
        #
        for shader_name in mesh_data.get("materials", []):
            if shader_name not in shaders_data:
                print(f"[WARNING] Shader '{shader_name}' not found in JSON, skipping.")
                continue

            shader_info = shaders_data[shader_name]
            print(f"[INFO] Processing material: {shader_name}")

            mat = bpy.data.materials.get(shader_name)
            if mat:
                print(f"[DEBUG] Found existing material '{shader_name}'")
            else:
                mat = bpy.data.materials.new(name=shader_name)
                print(f"[DEBUG] Created new material '{shader_name}'")

            if not mat.use_nodes:
                mat.use_nodes = True

            nodes = mat.node_tree.nodes
            links = mat.node_tree.links

            while nodes:
                nodes.remove(nodes[0])

            # Create Principled BSDF + Output
            principled_node = nodes.new("ShaderNodeBsdfPrincipled")
            output_node = nodes.new("ShaderNodeOutputMaterial")
            links.new(principled_node.outputs["BSDF"], output_node.inputs["Surface"])

            textures_dict = shader_info.get("textures", {})
            values_dict = shader_info.get("values", {})

            print(f"[DEBUG] Found {len(textures_dict)} textures, {len(values_dict)} numeric attributes in '{shader_name}'")

            #
            # 1) Connect TEXTURES
            #
            for tex_attr, tex_info in textures_dict.items():
                file_path = tex_info.get("filePath", "")
                is_udim = tex_info.get("udim", False)

                if not file_path or not os.path.isfile(file_path):
                    print(f"[WARNING] Texture file not found: {file_path}")
                    continue

                print(f"[INFO]  - Loading '{tex_attr}' texture: {file_path} (UDIM={is_udim})")

                tex_node = nodes.new("ShaderNodeTexImage")
                tex_node.label = tex_attr
                tex_node.image = bpy.data.images.load(file_path)

                if is_udim:
                    set_udim(tex_node.image, file_path)

                tex_node.image.colorspace_settings.name = 'sRGB' if tex_attr == "baseColor" else 'Non-Color'

                if tex_attr in PRINCIPLED_43_SOCKET_MAP:
                    idx = PRINCIPLED_43_SOCKET_MAP[tex_attr]
                    if idx < len(principled_node.inputs):
                        links.new(tex_node.outputs["Color"], principled_node.inputs[idx])

            #
            # 2) Numeric VALUES
            #
            for val_attr, val_data in values_dict.items():
                assigned = set_principled_value(val_attr, val_data, principled_node)
                if not assigned:
                    print(f"[INFO] Could not assign '{val_attr}'={val_data} to Principled.")

            # Assign material
            print(f"[INFO] Assigning material '{mat.name}' to '{transform_name_clean}'")
            transform_obj.data.materials.append(mat)

            organize_nodes(mat.node_tree, output_node)

    print("[INFO] Finished importing AI Standard Surface data.\n")


# Example usage:
# json_file_path = r"C:/Users/rioux/Desktop/ai_standard_surface_data.json"
# import_ai_standard_surface_data(json_file_path)

import bpy
import json
import os
import re

#
# 1) Map your Arnold attributes -> Blender 4.3 Principled BSDF socket indices
#
PRINCIPLED_43_SOCKET_MAP = {
    "baseColor": 0,
    "metalness": 1,
    "diffuseRoughness": 2,          # Also used for 'specularRoughness' if needed
    "specularRoughness": 2,         # Map Specular Roughness to Diffuse Roughness
    "subsurfaceAnisotropy": 11,
    "subsurfaceColor": 8,
    "specularAnisotropy": 14,
    "specularRotation": 15,
    "subsurface": 7,
    "transmission": 17,
    "specularColor": 13,
    "sheen": 23,
    "sheenRoughness": 24,
    "sheenColor": 25,
    "emission": 27,
    "emissionColor": 26,
    "coat": 18,
    "coatRoughness": 19,
    "coatIOR": 20,
    "coatColor": 21,
    "thinFilmThickness": 28,
    "thinFilmIOR": 29,
}


def set_udim(image, file_path):
    """
    Attempt to replace 4-digit tiles in 'file_path' with '<UDIM>' and set image.source = 'TILED'.

    Checks:
      1) Dot-based:  myTexture.1001.png  => myTexture.<UDIM>.png
      2) Underscore: myTexture_1001.png => myTexture_<UDIM>.png
    """
    dot_pattern = re.sub(r'\.(\d{4})(\.\w+)$', r'.<UDIM>\2', file_path)
    under_pattern = re.sub(r'_(\d{4})(\.\w+)$', r'_<UDIM>\2', file_path)

    if dot_pattern != file_path:
        image.filepath = dot_pattern
        image.source = 'TILED'
        print(f"[DEBUG] Using dot-based UDIM => {dot_pattern}")
    elif under_pattern != file_path:
        image.filepath = under_pattern
        image.source = 'TILED'
        print(f"[DEBUG] Using underscore-based UDIM => {under_pattern}")
    else:
        print(f"[WARNING] Could not detect a 4-digit UDIM pattern in '{file_path}'.")


def set_principled_value(attr, val, principled_node):
    """
    Assigns a numeric or color 'val' to the Principled BSDF node's input
    as defined by PRINCIPLED_43_SOCKET_MAP. Also auto-converts float vs. color
    to avoid dimension errors.

    Special logic for 'subsurfaceColor':
      - We'll only use the first 3 channels (R,G,B) from val, then set alpha=1.
    """
    if attr not in PRINCIPLED_43_SOCKET_MAP:
        print(f"[WARNING] No known Principled input index for '{attr}' (Blender 4.3). Skipping.")
        return False

    socket_index = PRINCIPLED_43_SOCKET_MAP[attr]
    if socket_index >= len(principled_node.inputs):
        print(f"[WARNING] Principled node has only {len(principled_node.inputs)} inputs; "
              f"index {socket_index} invalid for '{attr}'.")
        return False

    target_socket = principled_node.inputs[socket_index]
    current_def = target_socket.default_value

    # If this is 'subsurfaceColor', ensure we only use first 3 channels
    if attr == "subsurfaceColor":
        if isinstance(val, (list, tuple)):
            # Use first three elements as (R, G, B). 

            r = float(val[0]) if len(val) > 0 else 0.0
            g = float(val[1]) if len(val) > 1 else 0.0
            b = float(val[2]) if len(val) > 2 else 0.0
            target_socket.default_value = (r, g, b)
            print(f"[DEBUG] Set 'subsurfaceColor' => Subsurface Radius ( {r}, {g}, {b} ) at socket #{socket_index}")
            return True
        else:
            print(f"[WARNING] 'subsurfaceColor' expected a 3-float list/tuple, got '{val}'.")
            return False



    # Otherwise, proceed with normal logic
    if isinstance(current_def, float):
        # single float
        try:
            if isinstance(val, (list, tuple)):
                float_val = float(val[0])
            else:
                float_val = float(val)
            target_socket.default_value = float_val
            print(f"[DEBUG] Set Principled float socket #{socket_index} to {float_val} for '{attr}'.")
        except (ValueError, IndexError, TypeError):
            print(f"[WARNING] Could not convert '{val}' to single float for '{attr}'. Skipping.")
            return False

    elif isinstance(current_def, bpy.types.bpy_prop_array):
        # color or vector

        
        needed_len = len(current_def)
        if isinstance(val, (list, tuple)):
            new_val = list(val)
        else:
            new_val = [float(val)] * (needed_len - 1) + [1.0]

        if len(new_val) < needed_len:
            new_val += [1.0] * (needed_len - len(new_val))
        new_val = new_val[:needed_len]

        try:
            new_val = [float(x) for x in new_val]
        except ValueError:
            print(f"[WARNING] Can't convert '{val}' into float array for '{attr}'. Skipping.")
            return False

        target_socket.default_value = tuple(new_val)
        print(f"[DEBUG] Set Principled color socket #{socket_index} to {tuple(new_val)} for '{attr}'.")

    else:
        print(f"[WARNING] Socket #{socket_index} default_value is neither float nor tuple. Skipping '{attr}'.")
        return False

    return True


def recursive_organize(current_node, level, offset):

    next_level = level + 1

    y_level = -1

    node_above = None

    for node_input in current_node.inputs:
        
        for link in node_input.links:
            y_level += 1


            from_node = link.from_node

            node_above_height = 0

            if node_above:
                node_above_height = node_above.height
            
            

            from_node.location.x = current_node.location.x   + (- current_node.width - from_node.width * 2)  - offset
            from_node.location.y = current_node.location.y   + (-node_above_height) - (y_level * offset)

            node_above = from_node

            recursive_organize(from_node, next_level, offset)
        
            


def organize_nodes(node_tree, output_node):

    offset = 200
    recursive_organize(output_node, 0, offset)




def import_ai_standard_surface_data(json_path):
    print(f"[INFO] Loading JSON from {json_path}")
    if not os.path.exists(json_path):
        print(f"[ERROR] JSON file does not exist: {json_path}")
        return

    with open(json_path, "r") as f:
        data = json.load(f)

    print(f"[DEBUG] JSON top-level keys: {list(data.keys())}")

    for mesh_name, mesh_data in data.items():
        transform_name = mesh_data.get("transform")
        if not transform_name:
            print(f"[WARNING] No transform name for mesh '{mesh_name}', skipping.")
            continue

        transform_name_clean = transform_name.split('|')[-1]
        print(f"\n[INFO] Looking for Blender object '{transform_name_clean}' "
              f"(original Maya name: '{transform_name}')")

        transform_obj = bpy.data.objects.get(transform_name_clean)
        if not transform_obj:
            print(f"[WARNING] Object '{transform_name_clean}' not found, skipping.")
            continue
        elif transform_obj.type != 'MESH':
            print(f"[WARNING] '{transform_name_clean}' is not a MESH, skipping.")
            continue

        print(f"[INFO] Found mesh: {transform_name_clean}. Clearing existing materials...")
        transform_obj.data.materials.clear()

        #
        # Process each material
        #
        for material_data in mesh_data.get("materials", []):

            
            mat_name = material_data.get("name", "UnnamedMaterial")
            print(f"\n[INFO] Processing material: {mat_name}")

            mat = bpy.data.materials.get(mat_name)
            if mat:
                print(f"[DEBUG] Found existing material '{mat_name}'")
            else:
                mat = bpy.data.materials.new(name=mat_name)
                print(f"[DEBUG] Created new material '{mat_name}'")

            if not mat.use_nodes:
                mat.use_nodes = True

            # Clear existing nodes
            nodes = mat.node_tree.nodes
            links = mat.node_tree.links


            while nodes:
                nodes.remove(nodes[0])

            # Create Principled BSDF + Output
            principled_node = nodes.new("ShaderNodeBsdfPrincipled")
            #principled_node.location = (0, 0)
            output_node = nodes.new("ShaderNodeOutputMaterial")
            #output_node.location = (300, 0)

            links.new(principled_node.outputs["BSDF"], output_node.inputs["Surface"])

            textures_dict = material_data.get("textures", {})
            values_dict   = material_data.get("values", {})

            print(f"[DEBUG] Found {len(textures_dict)} textures, {len(values_dict)} numeric attrs in '{mat_name}'")

            #
            # 1) Connect TEXTURES
            #
            for tex_attr, tex_info in textures_dict.items():
                if isinstance(tex_info, dict):
                    file_path = tex_info.get("filePath", "")
                    is_udim   = tex_info.get("udim", False)
                elif isinstance(tex_info, str):
                    file_path = tex_info
                    is_udim   = False
                else:
                    print(f"[WARNING] Texture info for '{tex_attr}' is neither dict nor string. Skipping.")
                    continue

                if not file_path:
                    print(f"[WARNING] No file path for '{tex_attr}'. Skipping.")
                    continue

                if not os.path.isfile(file_path):
                    print(f"[WARNING] Texture file not found: {file_path}")
                    continue

                print(f"[INFO]  - Loading '{tex_attr}' texture: {file_path} (UDIM={is_udim})")

                tex_node = nodes.new("ShaderNodeTexImage")
                tex_node.label = tex_attr
                #tex_node.location = (-300, 0)

                try:
                    tex_node.image = bpy.data.images.load(file_path)
                except RuntimeError as e:
                    print(f"[ERROR] Could not load image {file_path}: {e}")
                    nodes.remove(tex_node)
                    continue

                if is_udim:
                    set_udim(tex_node.image, file_path)

                # baseColor => sRGB; everything else => Non-Color
                if tex_attr == "baseColor":
                    tex_node.image.colorspace_settings.name = 'sRGB'
                else:
                    tex_node.image.colorspace_settings.name = 'Non-Color'

                # Decide how to link by attribute
                if tex_attr == "normalCamera":
                    normal_map_node = nodes.new("ShaderNodeNormalMap")
                    #normal_map_node.location = (-500, 0)
                    links.new(tex_node.outputs["Color"], normal_map_node.inputs["Color"])
                    links.new(normal_map_node.outputs["Normal"], principled_node.inputs["Normal"])

                elif tex_attr == "displacement":
                    disp_node = nodes.new("ShaderNodeDisplacement")
                    #disp_node.location = (-500, -200)
                    links.new(tex_node.outputs["Color"], disp_node.inputs["Height"])
                    links.new(disp_node.outputs["Displacement"], output_node.inputs["Displacement"])

                elif tex_attr in PRINCIPLED_43_SOCKET_MAP:
                    idx = PRINCIPLED_43_SOCKET_MAP[tex_attr]
                    if idx < len(principled_node.inputs):
                        links.new(tex_node.outputs["Color"], principled_node.inputs[idx])
                        print(f"[DEBUG] Connected '{tex_attr}' texture to Principled input #{idx}.")
                    else:
                        print(f"[WARNING] Principled has only {len(principled_node.inputs)} inputs; can't link {tex_attr}.")
                else:
                    print(f"[WARNING] No dedicated code for texture '{tex_attr}'. Skipping...")

            #
            # 2) Numeric VALUES
            #
            for val_attr, val_data in values_dict.items():
                # Skip if there's already a texture for this attr
                # if val_attr in textures_dict:
                #     continue

                # Also skip "base" if ignoring
                if val_attr == "base":
                    print("[INFO] Skipping numeric 'base' attribute as requested.")
                    continue

                assigned = set_principled_value(val_attr, val_data, principled_node)
                if not assigned:
                    print(f"[INFO] Could not assign '{val_attr}'={val_data} to Principled. No matching input?")

            # Assign material
            print(f"[INFO] Assigning material '{mat.name}' to '{transform_name_clean}'")
            transform_obj.data.materials.append(mat)

            node_tree = mat.node_tree
            organize_nodes(node_tree, output_node)



    print("[INFO] Finished importing AI Standard Surface data.\n")

    
# Example usage:
# json_file_path = r"C:/Users/rioux/Desktop/riouxl_immeuble_v01/ai_standard_surface_data.json"
# import_ai_standard_surface_data(json_file_path)

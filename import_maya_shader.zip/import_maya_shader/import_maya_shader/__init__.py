bl_info = {
    "name": "Import Maya Shader",
    "author": "BlenderBob, Thnkerboi",
    "version": (1, 0, 0),
    "blender": (4, 1, 0),
    "description": "Imports Maya Shader from JSON File exported from a Exporter that matches this addon",
    "doc_url": "",
    "tracker_url": "",
    "category": "Importer",
}

import bpy
from . import operator_import_maya_shader

modules = [operator_import_maya_shader]


def register():
    for module in modules:
        module.register()


def unregister():
    for module in modules:
        module.unregister()


if __name__ == "__main__":
    register()

import bpy
from . import import_maya_shader



from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator


class IMPORT_OT_Import_Maya_Shader(Operator, ImportHelper):
    """Imports Maya Shader from JSON File exported from a Exporter that matches this addon """
    bl_idname = "import.maya_shader"
    bl_label = "Import Maya Shader"

    filename_ext = ".json"

    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):

        import_maya_shader.import_ai_standard_surface_data(self.filepath)

        return {"FINISHED"}


def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_Import_Maya_Shader.bl_idname, text="Maya Shader (.json)")


classes = [
    IMPORT_OT_Import_Maya_Shader,
]
menus = [
    menu_func_import, 
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    for menu in menus:

        bpy.types.TOPBAR_MT_file_import.append(menu)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    for menu in menus:
        bpy.types.TOPBAR_MT_file_import.remove(menu)


if __name__ == "__main__":
    register()


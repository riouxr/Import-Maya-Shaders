import os
import bpy
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty
from bpy.types import Operator
from . import import_maya_shader


class IMPORT_OT_Import_Maya_Shader(Operator, ImportHelper):
    """Import a Maya to Blender export: picks the JSON file, automatically
    imports the paired FBX (same name, same folder) first, then applies
    all materials and lights from the JSON."""
    bl_idname  = "import.maya_shader"
    bl_label   = "Maya Scene (.fbx + .json)"

    filename_ext = ".json"
    filter_glob: StringProperty(
        default="*.json",
        options={"HIDDEN"},
        maxlen=255,
    )

    def execute(self, context):
        json_path = self.filepath

        if not os.path.isfile(json_path):
            self.report({"ERROR"}, "JSON not found: " + json_path)
            return {"CANCELLED"}

        # ── Locate paired FBX ─────────────────────────────────────────────
        fbx_path = os.path.splitext(json_path)[0] + ".fbx"

        if not os.path.isfile(fbx_path):
            self.report({"ERROR"}, "Paired FBX not found: " + fbx_path)
            return {"CANCELLED"}

        # ── 1. Import FBX ─────────────────────────────────────────────────
        # bpy.ops calls inside an operator require 'EXEC_DEFAULT' to run
        # with the correct context; without it they silently do nothing.
        self.report({"INFO"}, "Importing FBX: " + fbx_path)
        try:
            result = bpy.ops.wm.fbx_import("EXEC_DEFAULT", filepath=fbx_path, global_scale=100.0)
            if "FINISHED" not in result:
                self.report({"ERROR"}, "FBX import returned: " + str(result))
                return {"CANCELLED"}
        except Exception as e:
            self.report({"ERROR"}, "FBX import failed: " + str(e))
            return {"CANCELLED"}

        # Force Blender to finish registering the imported objects before
        # we try to look them up by name in the JSON application step.
        bpy.context.view_layer.update()

        # ── 2. Apply shaders & lights from JSON ───────────────────────────
        self.report({"INFO"}, "Applying shaders from JSON: " + json_path)
        import_maya_shader.import_ai_standard_surface_data(json_path)

        self.report({"INFO"}, "Maya scene import complete.")
        return {"FINISHED"}


def menu_func_import(self, context):
    self.layout.operator(
        IMPORT_OT_Import_Maya_Shader.bl_idname,
        text="Maya Scene (.fbx + .json)",
    )


classes = [IMPORT_OT_Import_Maya_Shader]
menus   = [menu_func_import]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    for menu in menus:
        bpy.types.TOPBAR_MT_file_import.append(menu)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    for menu in menus:
        bpy.types.TOPBAR_MT_file_import.remove(menu)


if __name__ == "__main__":
    register()

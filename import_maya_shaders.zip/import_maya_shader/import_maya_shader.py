import bpy
import json
import math
import os
import re

try:
    import mathutils
except ImportError:
    mathutils = None

IS_BLENDER_4 = bpy.app.version >= (4, 0, 0)

# ─────────────────────────────────────────────────────────────────────────────
# Arnold attr → Principled BSDF socket name (Blender 4.x)
# ─────────────────────────────────────────────────────────────────────────────
PRINCIPLED_SOCKETS = {
    "baseColor":         "Base Color",
    "metalness":         "Metallic",
    "specular":          "Specular IOR Level",
    "specularRoughness": "Roughness",
    "subsurface":        "Subsurface Weight",
    "subsurfaceColor":   "Subsurface Color",
    "subsurfaceRadius":  "Subsurface Radius",
    "transmission":      "Transmission Weight",
    "emissionColor":     "Emission Color",
    "coat":              "Coat Weight",
    "coatRoughness":     "Coat Roughness",
    "normalCamera":      "Normal",
    "opacity":           "Alpha",
}

# Principled BSDF sockets that expect a scalar (greyscale) value.
# When connecting a texture node to one of these sockets we must always
# use the node's "Color" output — never "Alpha" — because Blender reads
# the RGB channels as the greyscale value for these inputs.
PRINCIPLED_SCALAR_SOCKETS = {
    "Metallic",
    "Roughness",
    "Specular IOR Level",
    "Coat Weight",
    "Coat Roughness",
    "Sheen Weight",
    "Sheen Roughness",
    "Anisotropic",
    "Anisotropic Rotation",
    "IOR",
    "Transmission Weight",
    "Subsurface Weight",
}

# Arnold attributes that map directly to a Blender light property
# { arnold_attr: (blender_property, conversion_fn_or_None) }
LIGHT_ATTR_MAP = {
    "aiCastShadows": ("use_shadow",      None),
    "aiRadius":      ("shadow_soft_size", None),
    "aiSpread":      ("spread",           None),
    # blenderAngle and blenderSpotSize/Blend are pre-computed in the exporter
}

# Arnold attributes with no Blender equivalent — stored as custom properties
LIGHT_CUSTOM_PROPS = [
    "aiDiffuse", "aiSpecular", "aiSss", "aiIndirect", "aiVolume",
    "aiMaxBounces", "aiCastVolumetricShadows", "aiShadowDensity",
    "aiShadowColor", "aiSamples", "aiNormalize", "aiRoundness",
    "aiSoftEdge", "aiFormat", "aiPortalMode",
]


# ─────────────────────────────────────────────────────────────────────────────
# Y-up (Maya) → Z-up (Blender) — applied only to newly created lights
# ─────────────────────────────────────────────────────────────────────────────

def yup_to_zup_location(t):
    return (t[0], -t[2], t[1])


def yup_to_zup_rotation(r_deg):
    rx = mathutils.Matrix.Rotation(math.radians(r_deg[0]), 4, 'X')
    ry = mathutils.Matrix.Rotation(math.radians(r_deg[1]), 4, 'Y')
    rz = mathutils.Matrix.Rotation(math.radians(r_deg[2]), 4, 'Z')
    maya_mat  = rz @ ry @ rx
    basis_fix = mathutils.Matrix.Rotation(math.radians(-90), 4, 'X')
    return (basis_fix @ maya_mat @ basis_fix.inverted()).to_euler('XYZ')


# ─────────────────────────────────────────────────────────────────────────────
# Mix-color node helpers (Blender 4.x vs 3.x)
# ─────────────────────────────────────────────────────────────────────────────

def new_mix_color_node(nodes, blend_type="MIX"):
    if IS_BLENDER_4:
        node = nodes.new("ShaderNodeMix")
        node.data_type  = "RGBA"
        node.blend_type = blend_type
    else:
        node = nodes.new("ShaderNodeMixRGB")
        node.blend_type = blend_type
    return node


def mix_input_a(n):
    if IS_BLENDER_4:
        s = n.inputs.get("A");      return s if s else n.inputs[6]
    s = n.inputs.get("Color1"); return s if s else n.inputs[1]

def mix_input_b(n):
    if IS_BLENDER_4:
        s = n.inputs.get("B");      return s if s else n.inputs[7]
    s = n.inputs.get("Color2"); return s if s else n.inputs[2]

def mix_input_fac(n):
    if IS_BLENDER_4:
        s = n.inputs.get("Factor"); return s if s else n.inputs[0]
    s = n.inputs.get("Fac");    return s if s else n.inputs[0]

def mix_output(n):
    if IS_BLENDER_4:
        s = n.outputs.get("Result"); return s if s else n.outputs[2]
    s = n.outputs.get("Color");  return s if s else n.outputs[0]

def is_mix_node(n):
    return isinstance(n, bpy.types.ShaderNodeMix if IS_BLENDER_4
                         else bpy.types.ShaderNodeMixRGB)


# ─────────────────────────────────────────────────────────────────────────────
# Socket helpers
# ─────────────────────────────────────────────────────────────────────────────

def resolve_output(b_node, name):
    if is_mix_node(b_node):
        return mix_output(b_node)
    s = b_node.outputs.get(name)
    if s is None:
        available = [o.name for o in b_node.outputs]
        if available:
            print(f"  [WARN] Output '{name}' not on '{b_node.name}' "
                  f"(available: {available}), using first")
            s = b_node.outputs[0]
        else:
            print(f"  [WARN] Output '{name}' not on '{b_node.name}' — node has NO outputs!")
    return s


def resolve_input(b_node, blender_in, maya_in=""):
    if is_mix_node(b_node):
        l = blender_in.lower()
        if "color1" in l or blender_in in ("A", "Color1") or maya_in.endswith("1"):
            return mix_input_a(b_node)
        if "color2" in l or blender_in in ("B", "Color2") or maya_in.endswith("2"):
            return mix_input_b(b_node)
        if "fac" in l or "factor" in l or blender_in in ("Fac", "Factor"):
            return mix_input_fac(b_node)
        return mix_input_a(b_node)
    s = b_node.inputs.get(blender_in)
    if s is None:
        print(f"  [WARN] Input '{blender_in}' not on '{b_node.name}'. "
              f"Available: {[i.name for i in b_node.inputs]}")
    return s


def safe_link(links, out_sock, in_sock, label=""):
    if out_sock is None or in_sock is None:
        print(f"  [SKIP link] '{label}' — None socket")
        return False
    try:
        links.new(out_sock, in_sock)
        print(f"  [LINK] {label}")
        return True
    except Exception as e:
        print(f"  [ERROR link] '{label}': {e}")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# UDIM
# ─────────────────────────────────────────────────────────────────────────────

def apply_udim(image, fp):
    p1 = re.sub(r'\.(\d{4})(\.\w+)$', r'.<UDIM>\2', fp)
    p2 = re.sub(r'_(\d{4})(\.\w+)$',  r'_<UDIM>\2',  fp)
    if p1 != fp:   image.filepath = p1; image.source = 'TILED'
    elif p2 != fp: image.filepath = p2; image.source = 'TILED'


# ─────────────────────────────────────────────────────────────────────────────
# Shader node creation
# ─────────────────────────────────────────────────────────────────────────────

def create_node(node_tree, node_id, node_data):
    b_type  = node_data.get("blenderType")
    subtype = node_data.get("blenderSubtype")
    attrs   = node_data.get("attributes", {})
    if not b_type:
        return None

    if b_type == "ShaderNodeMixRGB":
        try:
            node = new_mix_color_node(node_tree.nodes, subtype or "MIX")
            node.name = node.label = node_id
            try:
                fac = attrs.get("blender") or attrs.get("mix") or 1.0
                mix_input_fac(node).default_value = float(fac)
            except Exception:
                pass
            for key, fn in [("input1", mix_input_a), ("input2", mix_input_b)]:
                v = attrs.get(key)
                if v and isinstance(v, (list, tuple)) and len(v) >= 3:
                    try: fn(node).default_value = (*v[:3], 1.0)
                    except Exception: pass
            print(f"  [NODE] Mix-{subtype} '{node_id}'")
            return node
        except Exception as e:
            print(f"  [ERROR] Mix node '{node_id}': {e}")
            return None

    try:
        node = node_tree.nodes.new(b_type)
    except Exception as e:
        print(f"  [ERROR] nodes.new('{b_type}') for '{node_id}': {e}")
        return None
    node.name = node.label = node_id

    if b_type == "ShaderNodeTexImage":
        fp        = attrs.get("fileTextureName", "")
        is_udim   = attrs.get("udim", False)
        alpha_lum = attrs.get("alphaIsLuminance", False)
        use_srgb  = ("srgb" in (attrs.get("colorSpace") or "").lower()) and not alpha_lum
        if fp and os.path.isfile(fp):
            try:
                img = bpy.data.images.load(fp, check_existing=True)
                node.image = img
                if is_udim: apply_udim(img, fp)
                img.colorspace_settings.name = "sRGB" if use_srgb else "Non-Color"
                print(f"  [TEX] {os.path.basename(fp)} sRGB={use_srgb} UDIM={is_udim}")
            except Exception as e:
                print(f"  [WARN] Texture load '{fp}': {e}")
        else:
            print(f"  [WARN] Not found: '{fp}'")

    elif b_type == "ShaderNodeMapping":
        try:
            node.inputs["Scale"].default_value    = (float(attrs.get("repeatU", 1)), float(attrs.get("repeatV", 1)), 1.0)
            node.inputs["Location"].default_value = (float(attrs.get("offsetU", 0)), float(attrs.get("offsetV", 0)), 0.0)
            node.inputs["Rotation"].default_value = (0.0, 0.0, float(attrs.get("rotateUV", 0)))
        except Exception as e: print(f"  [WARN] Mapping '{node_id}': {e}")

    elif b_type == "ShaderNodeNormalMap":
        try: node.inputs["Strength"].default_value = float(attrs.get("strength", 1.0))
        except Exception as e: print(f"  [WARN] NormalMap '{node_id}': {e}")

    elif b_type == "ShaderNodeBump":
        try: node.inputs["Strength"].default_value = float(attrs.get("bumpDepth", 1.0))
        except Exception as e: print(f"  [WARN] Bump '{node_id}': {e}")

    elif b_type == "ShaderNodeMath":
        if subtype:
            try: node.operation = subtype
            except Exception as e: print(f"  [WARN] Math op '{node_id}': {e}")
        for key, idx in [("input1", 0), ("input1X", 0), ("input2", 1),
                         ("input2X", 1), ("conversionFactor", 1)]:
            v = attrs.get(key)
            if v is not None and idx < len(node.inputs):
                try: node.inputs[idx].default_value = float(v[0] if isinstance(v, (list, tuple)) else v)
                except Exception: pass

    elif b_type == "ShaderNodeVectorMath":
        if subtype:
            try: node.operation = subtype
            except Exception as e: print(f"  [WARN] VectorMath '{node_id}': {e}")

    elif b_type == "ShaderNodeGamma":
        try: node.inputs["Gamma"].default_value = float(attrs.get("gammaX", 2.2))
        except Exception as e: print(f"  [WARN] Gamma '{node_id}': {e}")

    elif b_type == "ShaderNodeClamp":
        try:
            node.inputs["Min"].default_value = float(attrs.get("minR", 0.0))
            node.inputs["Max"].default_value = float(attrs.get("maxR", 1.0))
        except Exception as e: print(f"  [WARN] Clamp '{node_id}': {e}")

    elif b_type == "ShaderNodeValToRGB":
        try:
            cr = node.color_ramp
            entries = attrs.get("rampEntries", [])
            if entries:
                while len(cr.elements) > 1:
                    cr.elements.remove(cr.elements[-1])
                for i, e in enumerate(sorted(entries, key=lambda x: x["position"])):
                    el = cr.elements[0] if i == 0 else cr.elements.new(e["position"])
                    el.position = e["position"]
                    c = e["color"]
                    el.color = (*c[:3], 1.0) if len(c) == 3 else tuple(c[:4])
        except Exception as e: print(f"  [WARN] ColorRamp '{node_id}': {e}")

    elif b_type == "ShaderNodeTexNoise":
        try:
            if "frequency" in attrs: node.inputs["Scale"].default_value  = float(attrs["frequency"])
            if "amplitude" in attrs: node.inputs["Detail"].default_value = float(attrs["amplitude"])
        except Exception as e: print(f"  [WARN] Noise '{node_id}': {e}")

    elif b_type == "ShaderNodeHueSaturation":
        try:
            node.inputs["Hue"].default_value        = 0.5 + float(attrs.get("hueOffset", 0.0))
            node.inputs["Saturation"].default_value = float(attrs.get("saturation", 1.0))
            node.inputs["Value"].default_value      = pow(2.0, float(attrs.get("exposure", 0.0)))
        except Exception as e: print(f"  [WARN] HueSat '{node_id}': {e}")

    print(f"  [NODE] {b_type} '{node_id}'")
    return node


def wire_nodes(node_tree, blender_nodes, nodes_data):
    links = node_tree.links
    for node_id, node_data in nodes_data.items():
        dst = blender_nodes.get(node_id)
        if not dst: continue
        input_map = node_data.get("inputMap", {})
        for maya_in, src_plug in node_data.get("connections", {}).items():
            try: src_node_id, src_maya_out = src_plug.rsplit('.', 1)
            except ValueError: continue
            src = blender_nodes.get(src_node_id)
            if not src: print(f"  [SKIP] Src missing: '{src_node_id}'"); continue
            blender_out = nodes_data.get(src_node_id, {}).get("outputMap", {}).get(src_maya_out, src_maya_out)
            blender_in  = input_map.get(maya_in, maya_in)
            safe_link(links, resolve_output(src, blender_out),
                      resolve_input(dst, blender_in, maya_in),
                      label=f"{src_node_id}.{blender_out} -> {node_id}.{blender_in}")


def set_principled_value(attr, val, p_node):
    sock_name = PRINCIPLED_SOCKETS.get(attr)
    if not sock_name: return
    sock = p_node.inputs.get(sock_name)
    if not sock: return
    try:
        if hasattr(sock.default_value, '__len__'):
            if isinstance(val, (list, tuple)) and len(val) >= 3:
                sock.default_value = (*val[:3], 1.0)
        else:
            sock.default_value = float(val[0] if isinstance(val, (list, tuple)) else val)
    except Exception as e:
        print(f"  [WARN] set_principled '{attr}': {e}")


def layout_nodes(node_tree, output_node):
    visited = set()
    def _r(cur):
        if cur.name in visited: return
        visited.add(cur.name)
        y, prev_h = 0, 0
        for inp in cur.inputs:
            for link in inp.links:
                fn = link.from_node
                fn.location.x = cur.location.x - cur.width - fn.width - 220
                fn.location.y = cur.location.y - y - prev_h
                y += fn.height + 30; prev_h = fn.height
                _r(fn)
    _r(output_node)




# ─────────────────────────────────────────────────────────────────────────────
# Light import — ported from standalone MayaExportLights addon
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
# Attribute setter — catches ALL exceptions, never silently swallows errors
# ─────────────────────────────────────────────────────────────────────────────

def set_attr(obj, attr, value, label=""):
    tag = label if label else attr
    try:
        setattr(obj, attr, value)
        print("    SET  {:<38} = {}".format(tag, value))
        return True
    except AttributeError:
        print("    MISS {:<38}   (attribute not found)".format(tag))
        return False
    except Exception as e:
        print("    ERR  {:<38}   {}".format(tag, e))
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Kelvin → RGB  (Tanner approximation, valid 1000–40000 K)
# Used when the Kelvin value is outside Blender's 800–12000 K limit,
# or as a fallback if Blender's temperature property is unavailable.
# ─────────────────────────────────────────────────────────────────────────────

BLENDER_TEMP_MIN     = 800.0
BLENDER_TEMP_MAX     = 12000.0
BLENDER_EXPOSURE_MIN = -10.0
BLENDER_EXPOSURE_MAX =  10.0

# ─────────────────────────────────────────────────────────────────────────────
# Arnold → Blender light intensity scale factor
#
# Arnold and Blender use different physical light units, which causes Blender
# scenes to appear far brighter than the original Maya/Arnold render.
#
# This is expressed as an EV (exposure value) offset so it is easy to tune:
#   -3.5 EV  = multiply all light energies by 2^(-3.5) ≈ 0.0884
#
# How to calibrate for your pipeline:
#   1. Render a simple grey-sphere test in both Maya/Arnold and Blender/Cycles
#      with a single area light at known intensity.
#   2. Match the middle-grey value in both renders.
#   3. The EV difference is your ARNOLD_TO_BLENDER_EV value.
#
# Common starting points:
#   -3.5  — Blender scene with Linear Rec.709 / Filmic colour management
#   -10.0 — if you use a raw/un-tonemapped colour space in Blender
#   0.0   — no correction (raw Maya values, usually too bright)
# ─────────────────────────────────────────────────────────────────────────────
ARNOLD_TO_BLENDER_EV    = -13.5           # ← tune this one number
ARNOLD_TO_BLENDER_LIGHT_SCALE = math.pow(2.0, ARNOLD_TO_BLENDER_EV)  # ≈ 0.0884


def kelvin_to_rgb(kelvin):
    t = max(1000.0, min(float(kelvin), 40000.0)) / 100.0
    r = 1.0 if t <= 66 else max(0.0, min(1.0,
        329.698727446 * math.pow(t - 60, -0.1332047592) / 255.0))
    g = (max(0.0, min(1.0, (99.4708025861 * math.log(t) - 161.1195681661) / 255.0))
         if t <= 66 else
         max(0.0, min(1.0, 288.1221695283 * math.pow(t - 60, -0.0755148492) / 255.0)))
    b = (0.0 if t <= 19 else 1.0 if t >= 66 else
         max(0.0, min(1.0,
             (138.5177312231 * math.log(t - 10) - 305.0447927307) / 255.0)))
    return (r, g, b)


def clamped_exposure(ev):
    c = max(BLENDER_EXPOSURE_MIN, min(float(ev), BLENDER_EXPOSURE_MAX))
    if c != float(ev):
        print("    CLAMP exposure {:.4f} → {:.4f} EV "
              "(Blender limit {}–{})".format(
                  ev, c, BLENDER_EXPOSURE_MIN, BLENDER_EXPOSURE_MAX))
    return c


# ─────────────────────────────────────────────────────────────────────────────
# Color temperature
#
# Blender's temperature property range is 800–12000 K.
# Arnold allows values up to ~30000 K.
#
# Strategy:
#   • If kelvin is within 800–12000 K → set use_temperature + temperature natively.
#     Try with use_nodes=False first (required on FBX-imported lights in Blender 4.2+
#     where use_nodes=True can shadow RNA properties).
#   • If kelvin is OUTSIDE 800–12000 K → convert to RGB via Kelvin formula and
#     apply as light.color. The colour will be correct even though the K slider
#     won't be active. A clear log message notes this happened.
# ─────────────────────────────────────────────────────────────────────────────

def apply_color_temperature(light, kelvin):
    in_range = BLENDER_TEMP_MIN <= float(kelvin) <= BLENDER_TEMP_MAX

    if in_range:
        # Try native temperature property (temporarily disable nodes if needed)
        prev_nodes = getattr(light, "use_nodes", None)
        if prev_nodes:
            try:
                light.use_nodes = False
            except Exception:
                pass

        ok = False
        try:
            light.use_temperature = True
            light.temperature     = float(kelvin)
            print("    SET  use_temperature = True")
            print("    SET  temperature     = {:.0f} K".format(kelvin))
            ok = True
        except Exception as e:
            print("    ERR  use_temperature / temperature: {}".format(e))

        if prev_nodes is not None and prev_nodes != getattr(light, "use_nodes", None):
            try:
                light.use_nodes = prev_nodes
            except Exception:
                pass

        if ok:
            return

    # Out of range OR native property failed — convert to RGB
    r, g, b = kelvin_to_rgb(kelvin)
    if not in_range:
        print("    NOTE {:.0f} K is outside Blender's 800–12000 K range. "
              "Applying as RGB colour instead.".format(kelvin))
    print("    SET  color (Kelvin→RGB {:.0f}K → "
          "{:.3f},{:.3f},{:.3f})".format(kelvin, r, g, b))
    set_attr(light, "color", (r, g, b),
             label="color (Kelvin→RGB {:.0f}K)".format(kelvin))


# ─────────────────────────────────────────────────────────────────────────────
# Common settings applied to every light type
# ─────────────────────────────────────────────────────────────────────────────

def apply_common(light, data):
    use_temp   = data.get("useColorTemp", False)
    color_temp = float(data.get("colorTemp", 6500.0))
    raw_color  = data.get("color", [1.0, 1.0, 1.0])

    # ── Color / temperature ───────────────────────────────────────────────
    if use_temp:
        apply_color_temperature(light, color_temp)
    else:
        set_attr(light, "color",
                 (raw_color[0], raw_color[1], raw_color[2]),
                 label="color ({:.3f}, {:.3f}, {:.3f})".format(*raw_color))

    # ── Energy & exposure ─────────────────────────────────────────────────
    intensity = float(data.get("intensity", 1.0))
    exposure  = float(data.get("exposure",  0.0))

    # Blender clamps its per-light exposure property to ±10 EV.
    # Any overflow must be folded into the energy value so the final
    # luminance matches Maya/Arnold.  We then also apply the global
    # Arnold→Blender unit-scale factor.
    clamped_exp   = clamped_exposure(exposure)
    overflow_ev   = exposure - clamped_exp          # 0 when within ±10 EV
    # Bake overflow + unit-scale correction into the energy:
    #   final_energy = intensity × 2^overflow × ARNOLD_TO_BLENDER_LIGHT_SCALE
    baked_energy  = (intensity
                     * math.pow(2.0, overflow_ev)
                     * ARNOLD_TO_BLENDER_LIGHT_SCALE)

    if overflow_ev != 0.0:
        print("    NOTE exposure {:.2f} EV clamped to {:.2f}; "
              "overflow ×{:.2f} baked into energy".format(
                  exposure, clamped_exp, math.pow(2.0, overflow_ev)))

    set_attr(light, "energy", baked_energy,
             label="energy ({}×2^{:.2f}×scale={:.4f})".format(
                 intensity, overflow_ev, baked_energy))

    ok_exp = set_attr(light, "exposure", clamped_exp,
                      label="exposure ({} EV → clamped {})".format(
                          exposure, clamped_exp))
    if not ok_exp:
        # Blender build without per-light exposure — fold it all into energy
        full_bake = (intensity
                     * math.pow(2.0, exposure)
                     * ARNOLD_TO_BLENDER_LIGHT_SCALE)
        set_attr(light, "energy", full_bake,
                 label="energy fully baked ({}×2^{}×scale={:.4f})".format(
                     intensity, exposure, full_bake))

    # ── Shadow ────────────────────────────────────────────────────────────
    cast = data.get("attributes", {}).get("aiCastShadows")
    if cast is not None:
        set_attr(light, "use_shadow", bool(cast),
                 label="use_shadow (aiCastShadows)")

    # ── Arnold-only → custom properties ──────────────────────────────────
    for prop in ["aiCastVolumetricShadows", "aiShadowDensity", "aiSamples",
                 "aiDiffuse", "aiSpecular", "aiSss",
                 "aiIndirect", "aiVolume", "aiMaxBounces"]:
        val = data.get("attributes", {}).get(prop)
        if val is not None:
            try:
                light["arnold_" + prop] = val
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
# Per-type import functions
# ─────────────────────────────────────────────────────────────────────────────

def import_point(light, data):
    print("  [POINT]")
    apply_common(light, data)
    radius = float(data.get("attributes", {}).get("aiRadius", 0.0))
    set_attr(light, "shadow_soft_size", radius,
             label="shadow_soft_size (aiRadius={})".format(radius))


def import_sun(light, data):
    print("  [SUN]")
    apply_common(light, data)
    angle_rad = float(data.get("attributes", {}).get(
        "blenderAngle", math.radians(0.526)))
    set_attr(light, "angle", angle_rad,
             label="angle ({:.4f} rad / {:.3f}°)".format(
                 angle_rad, math.degrees(angle_rad)))


def import_spot(light, data):
    """
    Spot cone mapping:

    Maya coneAngle    = the full angle of the bright (fully lit) beam, e.g. 100°.
                        This is what the artist sees as "the cone" in Maya.
    Maya penumbraAngle = soft falloff zone OUTSIDE the hard beam edge (degrees).
                        Positive = fades outside the cone; 0 = hard edge.

    Blender spot_size  = full outer angle where light reaches zero (radians).
    Blender spot_blend = 0 (hard edge at spot_size) → 1 (gradual from centre out).

    Correct mapping so "100° in Maya = 100° in Blender":
      spot_size  = coneAngle   (the bright cone IS spot_size)
      spot_blend = penumbraAngle / (coneAngle / 2)   clamped 0–1
                   (penumbra as a fraction of the half-angle)

    Previous wrong formula added 2×penumbra to coneAngle, giving 140° for
    a 100° cone with 20° penumbra — that's why Blender showed 140°.
    """
    attrs = data.get("attributes", {})
    print("  [SPOT]")

    cone   = float(attrs.get("coneAngle",    40.0))
    penumb = float(attrs.get("penumbraAngle", 0.0))

    # spot_size = the main cone angle, matching what the artist set in Maya
    spot_size_rad = math.radians(cone)
    # spot_blend = how much of the half-cone is soft falloff
    half = cone / 2.0
    blend = min(max(penumb / half, 0.0), 1.0) if half > 0 else 0.0

    radius = float(attrs.get("aiRadius", 0.0))

    print("    INFO cone={:.1f}° penumbra={:.1f}°"
          " → spot_size={:.4f}rad ({:.1f}°) blend={:.3f}".format(
              cone, penumb, spot_size_rad, cone, blend))

    apply_common(light, data)

    set_attr(light, "spot_size", spot_size_rad,
             label="spot_size ({:.4f} rad / {:.1f}°)".format(
                 spot_size_rad, cone))
    set_attr(light, "spot_blend", blend,
             label="spot_blend ({:.4f})".format(blend))
    set_attr(light, "shadow_soft_size", radius,
             label="shadow_soft_size (aiRadius={})".format(radius))


def import_area(light, data, is_new=False):
    """
    Area light size:
      rawScaleX/Y = Maya world-space scale in Maya units (cm).
      FBX imports at scene scale ×100 (cm→m), which is applied to object
      transforms. Light size values are set in scene units directly, so
      rawScaleX in cm = the correct value to use as light.size in metres
      after the FBX 100× scene scale is applied.
    """
    attrs = data.get("attributes", {})
    print("  [AREA]")
    apply_common(light, data)

    sx = float(attrs.get("rawScaleX", attrs.get("blenderSizeX", 1.0)))
    sy = float(attrs.get("rawScaleY", attrs.get("blenderSizeY", 1.0)))

    if is_new:
        # Newly created light — apply Maya scale directly as light size.
        size_x = sx * 2.0
        size_y = sy * 2.0
        print("    INFO size X={:.4f}  Y={:.4f}  (new light, ×2 applied)".format(size_x, size_y))
    else:
        # FBX-imported light — transform scale is already set by FBX.
        # light.size is an additional multiplier on top of scale.
        # Empirically confirmed: size=2.0 gives a perfect match with Maya.
        size_x = 2.0
        size_y = 2.0
        print("    INFO FBX-imported — light.size set to 2.0 (confirmed match)")

    roundness = float(attrs.get("aiRoundness", 0.0))
    is_round  = roundness >= 0.5
    if is_round:
        shape = "ELLIPSE" if abs(sx - sy) > 0.001 else "DISK"
    else:
        shape = "RECTANGLE" if abs(sx - sy) > 0.001 else "SQUARE"

    set_attr(light, "shape",  shape,  label="shape ({})".format(shape))
    set_attr(light, "size",   size_x, label="size   ({:.4f})".format(size_x))
    set_attr(light, "size_y", size_y, label="size_y ({:.4f})".format(size_y))

    spread = attrs.get("aiSpread")
    if spread is not None:
        set_attr(light, "spread", float(spread),
                 label="spread (aiSpread={})".format(spread))

    normalize = attrs.get("aiNormalize")
    if normalize is not None:
        set_attr(light, "use_area_light_normalized", bool(normalize),
                 label="use_area_light_normalized")


def import_skydome(data):
    print("  [WORLD]")
    world = bpy.context.scene.world
    if world is None:
        world = bpy.data.worlds.new("World")
        bpy.context.scene.world = world
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    nodes.clear()

    bg_node  = nodes.new("ShaderNodeBackground")
    out_node = nodes.new("ShaderNodeOutputWorld")
    links.new(bg_node.outputs["Background"], out_node.inputs["Surface"])
    out_node.location.x = 300

    intensity = float(data.get("intensity", 1.0))
    exposure  = float(data.get("exposure",  0.0))
    strength  = intensity * math.pow(2.0, exposure)
    bg_node.inputs["Strength"].default_value = strength
    print("    SET  Background Strength {:.4f} "
          "({}×2^{}={:.4f})".format(strength, intensity, exposure, strength))

    use_temp   = data.get("useColorTemp", False)
    color_temp = float(data.get("colorTemp", 6500.0))
    raw_color  = data.get("color", [1.0, 1.0, 1.0])
    attrs      = data.get("attributes", {})
    hdri       = attrs.get("hdriPath")

    if hdri and os.path.isfile(hdri):
        env = nodes.new("ShaderNodeTexEnvironment")
        tc  = nodes.new("ShaderNodeTexCoord")
        tc.location  = (-550, 0)
        env.location = (-300, 0)
        links.new(tc.outputs["Generated"], env.inputs["Vector"])
        links.new(env.outputs["Color"],    bg_node.inputs["Color"])
        try:
            img = bpy.data.images.load(hdri, check_existing=True)
            img.colorspace_settings.name = "Linear Rec.709"
            env.image = img
            print("    SET  HDRI = {}".format(os.path.basename(hdri)))
        except Exception as e:
            print("    ERR  HDRI load: {}".format(e))
    else:
        if use_temp:
            r, g, b = kelvin_to_rgb(color_temp)
            bg_node.inputs["Color"].default_value = (r, g, b, 1.0)
            print("    SET  Background Color Kelvin→RGB {:.0f}K "
                  "→ ({:.3f},{:.3f},{:.3f})".format(color_temp, r, g, b))
        else:
            bg_node.inputs["Color"].default_value = (*raw_color[:3], 1.0)
            print("    SET  Background Color = {}".format(raw_color[:3]))
        if hdri:
            print("    WARN HDRI not found on disk: {}".format(hdri))

    print("  [DONE] SkyDome → World shader")


# ─────────────────────────────────────────────────────────────────────────────
# Object lookup / creation
#
# After changing light.type, obj.data MUST be re-fetched.
# Changing the type replaces the C subtype. The old Python reference keeps
# base-class attributes but loses subtype-specific ones (shape, size, size_y,
# spot_size …). Re-fetching obj.data returns the correct subtype wrapper.
# ─────────────────────────────────────────────────────────────────────────────

def get_or_create_light(name, b_type):
    obj = bpy.data.objects.get(name)
    if obj and obj.type == 'LIGHT':
        if obj.data.type != b_type:
            obj.data.type = b_type
            print("  Converted type → {}".format(b_type))
        light = obj.data          # re-fetch AFTER possible type change
        return obj, light, False

    light = bpy.data.lights.new(name=name, type=b_type)
    obj   = bpy.data.objects.new(name=name, object_data=light)
    bpy.context.collection.objects.link(obj)
    return obj, light, True



# ─────────────────────────────────────────────────────────────────────────────
# NODE_REGISTRY — maps Maya node types to Blender equivalents.
# Used by normalize_shader_info() to enrich the generic-exporter format.
# Identical to the registry in MayaExportShaders.py.
# ─────────────────────────────────────────────────────────────────────────────
NODE_REGISTRY = {
    "file":             {"blenderType": "ShaderNodeTexImage",
                         "blenderSubtype": None,
                         "inputMap":  {"uvCoord": "Vector"},
                         "outputMap": {"outColor": "Color", "outAlpha": "Alpha", "outColorR": "Color"}},
    "place2dTexture":   {"blenderType": "ShaderNodeMapping",
                         "blenderSubtype": None,
                         "inputMap":  {},
                         "outputMap": {"outUV": "Vector"}},
    "bump2d":           {"blenderType": "ShaderNodeBump",
                         "blenderSubtype": None,
                         "inputMap":  {"bumpValue": "Height"},
                         "outputMap": {"outNormal": "Normal"}},
    "aiNormalMap":      {"blenderType": "ShaderNodeNormalMap",
                         "blenderSubtype": None,
                         "inputMap":  {"input": "Color"},
                         "outputMap": {"outValue": "Normal"}},
    "multiplyDivide":   {"blenderType": "ShaderNodeMath",
                         "blenderSubtype": "MULTIPLY",
                         "inputMap":  {"input1X": "Value", "input2X": "Value",
                                       "input1": "Value", "input2": "Value"},
                         "outputMap": {"outputX": "Value", "output": "Value"}},
    "addDoubleLinear":  {"blenderType": "ShaderNodeMath",
                         "blenderSubtype": "ADD",
                         "inputMap":  {"input1": "Value", "input2": "Value"},
                         "outputMap": {"output": "Value"}},
    "multDoubleLinear": {"blenderType": "ShaderNodeMath",
                         "blenderSubtype": "MULTIPLY",
                         "inputMap":  {"input1": "Value", "input2": "Value"},
                         "outputMap": {"output": "Value"}},
    "unitConversion":   {"blenderType": "ShaderNodeMath",
                         "blenderSubtype": "MULTIPLY",
                         "inputMap":  {"input": "Value"},
                         "outputMap": {"output": "Value"}},
    "aiAbs":            {"blenderType": "ShaderNodeMath",
                         "blenderSubtype": "ABSOLUTE",
                         "inputMap":  {"input": "Value"},
                         "outputMap": {"outValue": "Value"}},
    "vectorProduct":    {"blenderType": "ShaderNodeVectorMath",
                         "blenderSubtype": None,
                         "inputMap":  {"input1": "Vector", "input2": "Vector"},
                         "outputMap": {"output": "Vector"}},
    "blendColors":      {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "MIX",
                         "inputMap":  {"color1": "Color1", "color2": "Color2", "blender": "Fac"},
                         "outputMap": {"output": "Color"}},
    "layeredTexture":   {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "MIX",
                         "inputMap":  {},
                         "outputMap": {"outColor": "Color"}},
    "aiMultiply":       {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "MULTIPLY",
                         "inputMap":  {"input1": "Color1", "input2": "Color2"},
                         "outputMap": {"outColor": "Color"}},
    "aiAdd":            {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "ADD",
                         "inputMap":  {"input1": "Color1", "input2": "Color2"},
                         "outputMap": {"outColor": "Color"}},
    "aiSubtract":       {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "SUBTRACT",
                         "inputMap":  {"input1": "Color1", "input2": "Color2"},
                         "outputMap": {"outColor": "Color"}},
    "aiMix":            {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "MIX",
                         "inputMap":  {"input1": "Color1", "input2": "Color2", "mix": "Fac"},
                         "outputMap": {"outColor": "Color"}},
    "gammaCorrect":     {"blenderType": "ShaderNodeGamma",
                         "blenderSubtype": None,
                         "inputMap":  {"value": "Color", "gammaX": "Gamma"},
                         "outputMap": {"outValue": "Color"}},
    "clamp":            {"blenderType": "ShaderNodeClamp",
                         "blenderSubtype": None,
                         "inputMap":  {"inputR": "Value"},
                         "outputMap": {"outputR": "Result"}},
    "reverse":          {"blenderType": "ShaderNodeInvert",
                         "blenderSubtype": None,
                         "inputMap":  {"input": "Color"},
                         "outputMap": {"output": "Color"}},
    "luminance":        {"blenderType": "ShaderNodeRGBToBW",
                         "blenderSubtype": None,
                         "inputMap":  {"value": "Color"},
                         "outputMap": {"outValue": "Val"}},
    "hsvToRgb":         {"blenderType": "ShaderNodeHueSaturation",
                         "blenderSubtype": None,
                         "inputMap":  {"inHsv": "Color"},
                         "outputMap": {"outRgb": "Color"}},
    "aiColorCorrect":   {"blenderType": "ShaderNodeHueSaturation",
                         "blenderSubtype": None,
                         "inputMap":  {"input": "Color"},
                         "outputMap": {"outColor": "Color"}},
    "ramp":             {"blenderType": "ShaderNodeValToRGB",
                         "blenderSubtype": None,
                         "inputMap":  {"uvCoord": "Fac"},
                         "outputMap": {"outColor": "Color", "outAlpha": "Alpha"}},
    "noise":            {"blenderType": "ShaderNodeTexNoise",
                         "blenderSubtype": None,
                         "inputMap":  {"uvCoord": "Vector"},
                         "outputMap": {"outColor": "Color"}},
    "fractal":          {"blenderType": "ShaderNodeTexNoise",
                         "blenderSubtype": None,
                         "inputMap":  {"uvCoord": "Vector"},
                         "outputMap": {"outColor": "Color"}},
    # aiMixShader: blend two Arnold shaders (or colours) with a scalar weight.
    # Mapped to MixRGB so colour inputs from textures are handled correctly.
    # "mix" = 0 → full shader1,  "mix" = 1 → full shader2.
    "aiMixShader":      {"blenderType": "ShaderNodeMixRGB",
                         "blenderSubtype": "MIX",
                         "inputMap":  {"shader1": "Color1", "shader2": "Color2", "mix": "Fac"},
                         "outputMap": {"outColor": "Color"}},
}

# Root shader types — the node whose connections become Principled BSDF inputs
ROOT_SHADER_TYPES = {
    "aiStandardSurface", "VRayMtl", "lambert", "blinn", "phong",
}

# multiplyDivide operation index → Blender subtype
MULTIPLY_DIVIDE_OPS = {1: "MULTIPLY", 2: "DIVIDE", 3: "POWER"}
# vectorProduct operation index → Blender subtype
VECTOR_PRODUCT_OPS  = {0: "DOT_PRODUCT", 1: "CROSS_PRODUCT",
                       2: "VECTOR_MATRIX_PRODUCT", 3: "POINT_MATRIX_PRODUCT"}


def normalize_shader_info(shader_name, shader_info):
    """
    Accept either export format and return the format the importer needs:
      {"nodes": {node_id: enriched_node_data}, "inputs": {attr: src_plug_or_value}}

    Old format (MayaExportShaders.py):
      Has "nodes" and "inputs" keys already — pass through unchanged.

    New format (Advanced_MultiEngine_Maya_Exporter.py):
      Has a "graph" key containing a flat dict of ALL nodes including the root
      shader itself. Attributes and connections use raw Maya names only.
      We need to:
        1. Identify the root node (type in ROOT_SHADER_TYPES, or name == shader_name)
        2. Extract root connections → inputs  (these feed Principled BSDF)
        3. Extract root scalar attrs → inputs as {value:...} for unconnected sockets
        4. For every other node, look up NODE_REGISTRY to add blenderType,
           inputMap, outputMap. Mark unsupported nodes with supported=False.
        5. Patch multiplyDivide / vectorProduct blenderSubtype from their
           operation attribute.
    """
    # ── Already in old format ─────────────────────────────────────────────
    if "nodes" in shader_info:
        print(f"  [NORM] '{shader_name}' — old format (nodes+inputs), passing through")
        return shader_info

    graph = shader_info.get("graph", {})
    if not graph:
        return {"nodes": {}, "inputs": {}}

    # ── Find the root node ────────────────────────────────────────────────
    root_id   = None
    root_node = None

    # Prefer exact name match first (most reliable)
    if shader_name in graph:
        root_id   = shader_name
        root_node = graph[shader_name]
    else:
        # Fall back: first node whose mayaType is a root shader type
        for nid, nd in graph.items():
            if nd.get("mayaType") in ROOT_SHADER_TYPES:
                root_id   = nid
                root_node = nd
                break

    if root_node is None:
        print(f"  [WARN] normalize: could not find root node for '{shader_name}'")
        print(f"  [DIAG] graph keys: {list(graph.keys())}")
        print(f"  [DIAG] node types: { {k: v.get('mayaType') for k,v in graph.items()} }")
        return {"nodes": {}, "inputs": {}}

    print(f"  [NORM] root node = '{root_id}'  (mayaType={root_node.get('mayaType')})")
    root_attrs = root_node.get("attributes", {})
    root_conns = root_node.get("connections", {})
    print(f"  [NORM] root connections: {root_conns}")
    print(f"  [NORM] root attrs keys:  {list(root_attrs.keys())}")

    # ── Build inputs dict ─────────────────────────────────────────────────
    # Connected attrs → src plug string
    # Unconnected Principled BSDF attrs with a scalar/color value → {value: ...}
    inputs = {}
    for attr in PRINCIPLED_SOCKETS:
        if attr in root_conns:
            inputs[attr] = root_conns[attr]
        elif attr in root_attrs:
            inputs[attr] = {"value": root_attrs[attr]}
        else:
            pass  # attr not present on this shader — normal, skip silently

    # ── Build enriched nodes dict (exclude root) ──────────────────────────
    nodes = {}
    for nid, nd in graph.items():
        if nid == root_id:
            continue

        maya_type = nd.get("mayaType", "")
        reg       = NODE_REGISTRY.get(maya_type)
        attrs     = nd.get("attributes", {})
        conns     = nd.get("connections", {})

        if reg:
            subtype = reg["blenderSubtype"]

            # Patch operation-dependent subtypes
            if maya_type == "multiplyDivide":
                op      = attrs.get("operation", 1)
                subtype = MULTIPLY_DIVIDE_OPS.get(int(op) if op else 1, "MULTIPLY")
            elif maya_type == "vectorProduct":
                op      = attrs.get("operation", 0)
                subtype = VECTOR_PRODUCT_OPS.get(int(op) if op else 0, "DOT_PRODUCT")
            elif maya_type == "file":
                attrs["udim"] = (attrs.get("uvTilingMode") == 3)

            enriched = {
                "mayaType":       maya_type,
                "blenderType":    reg["blenderType"],
                "blenderSubtype": subtype,
                "inputMap":       reg["inputMap"],
                "outputMap":      reg["outputMap"],
                "supported":      True,
                "attributes":     attrs,
                "connections":    conns,
            }
        else:
            enriched = {
                "mayaType":       maya_type,
                "blenderType":    None,
                "blenderSubtype": None,
                "inputMap":       {},
                "outputMap":      {},
                "supported":      False,
                "attributes":     attrs,
                "connections":    conns,
            }

        nodes[nid] = enriched

    return {"nodes": nodes, "inputs": inputs}


def import_ai_standard_surface_data(json_path):
    print(f"\n{'='*60}")
    print(f"[IMPORT] {json_path}")
    print(f"[IMPORT] Blender {bpy.app.version_string}  (4.x={IS_BLENDER_4})")
    print('='*60)

    if not os.path.exists(json_path):
        print(f"[ERROR] File not found: {json_path}"); return

    with open(json_path, "r") as f:
        data = json.load(f)

    meshes_data  = data.get("meshes",  {})
    shaders_data = data.get("shaders", {})
    lights_data  = data.get("lights",  {})
    print(f"[INFO] {len(meshes_data)} meshes, {len(shaders_data)} shaders, "
          f"{len(lights_data)} lights\n")

    # ── Meshes & shaders ──────────────────────────────────────────────────
    for mesh_name, mesh_data in meshes_data.items():
        transform_name = (mesh_data.get("transform") or "").split('|')[-1]
        obj = bpy.data.objects.get(transform_name)

        if not obj:
            print(f"[SKIP] Object '{transform_name}' not in scene"); continue
        if obj.type != 'MESH':
            print(f"[SKIP] '{transform_name}' is not a MESH"); continue

        print(f"\n[MESH] '{transform_name}'")
        obj.data.materials.clear()

        for shader_name in mesh_data.get("materials", []):
            shader_info = shaders_data.get(shader_name)
            if not shader_info:
                print(f"  [SKIP] Shader '{shader_name}' missing"); continue

            # Normalize: convert generic-exporter "graph" format to the
            # registry-enriched "nodes"+"inputs" format the pipeline expects.
            shader_info = normalize_shader_info(shader_name, shader_info)

            print(f"\n  [MAT] '{shader_name}'")
            mat = (bpy.data.materials.get(shader_name)
                   or bpy.data.materials.new(name=shader_name))
            mat.use_nodes = True
            mat.node_tree.nodes.clear()

            nodes = mat.node_tree.nodes
            links = mat.node_tree.links

            p_node   = nodes.new("ShaderNodeBsdfPrincipled")
            out_node = nodes.new("ShaderNodeOutputMaterial")
            out_node.location.x = 300
            links.new(p_node.outputs["BSDF"], out_node.inputs["Surface"])

            nodes_data    = shader_info.get("nodes",  {})
            shader_inputs = shader_info.get("inputs", {})

            blender_nodes = {}
            unsupported   = []

            for node_id, node_data in nodes_data.items():
                if not node_data.get("supported", True):
                    unsupported.append(f"    - {node_id} ({node_data.get('mayaType')})")
                    continue
                bn = create_node(mat.node_tree, node_id, node_data)
                if bn: blender_nodes[node_id] = bn
                else:  print(f"  [FAIL] Could not create '{node_id}'")

            if unsupported:
                print("  [WARN] Unsupported Maya nodes (skipped):")
                for u in unsupported: print(u)
                # Cross-check: warn if a skipped node is actually needed by an input
                skipped_ids = {u.split()[1] for u in unsupported}
                for attr, src in shader_inputs.items():
                    if isinstance(src, str):
                        try:
                            needed_id = src.rsplit('.', 1)[0]
                            if needed_id in skipped_ids:
                                print(f"  [WARN] Input '{attr}' needs '{needed_id}' "
                                      f"but that node was skipped (unsupported type) — "
                                      f"'{attr}' will be UNCONNECTED")
                        except Exception:
                            pass

            # Inject UV TexCoord for every ShaderNodeMapping
            for node_id, bn in list(blender_nodes.items()):
                if isinstance(bn, bpy.types.ShaderNodeMapping):
                    tc = nodes.new("ShaderNodeTexCoord")
                    tc.name = tc.label = f"__uv__{node_id}"
                    links.new(tc.outputs["UV"], bn.inputs["Vector"])
                    blender_nodes[tc.name] = tc
                    print(f"  [UV] TexCoord -> '{node_id}'")

            print("  [WIRE] Inter-node:")
            wire_nodes(mat.node_tree, blender_nodes, nodes_data)

            print("  [WIRE] To Principled BSDF:")
            for attr, src in shader_inputs.items():
                if isinstance(src, dict):
                    set_principled_value(attr, src.get("value"), p_node)
                elif isinstance(src, str):
                    try: src_node_id, src_maya_out = src.rsplit('.', 1)
                    except ValueError: continue
                    src_bn    = blender_nodes.get(src_node_id)
                    sock_name = PRINCIPLED_SOCKETS.get(attr)
                    if not sock_name: continue
                    if not src_bn:
                        # Dig into why this node is missing to give a useful hint
                        raw_nd    = nodes_data.get(src_node_id, {})
                        maya_type = raw_nd.get("mayaType", "UNKNOWN")
                        supported = raw_nd.get("supported", True)
                        if not supported:
                            print(f"  [SKIP] '{src_node_id}' ({maya_type}) — unsupported Maya type, "
                                  f"no Blender equivalent in NODE_REGISTRY → '{attr}' UNCONNECTED")
                        elif src_node_id not in nodes_data:
                            print(f"  [SKIP] '{src_node_id}' — not present in nodes_data at all. "
                                  f"Check JSON export captured this node → '{attr}' UNCONNECTED")
                        else:
                            print(f"  [SKIP] '{src_node_id}' ({maya_type}) — create_node returned None "
                                  f"→ '{attr}' UNCONNECTED")
                        continue
                    blender_out = nodes_data.get(src_node_id, {}).get("outputMap", {}).get(src_maya_out, src_maya_out)
                    # Scalar Principled sockets (Roughness, Metallic, …) must
                    # receive the Color output of a texture node, not Alpha.
                    # Alpha carries the texture's transparency channel, while
                    # Color carries the actual pixel data we want.
                    if sock_name in PRINCIPLED_SCALAR_SOCKETS and blender_out == "Alpha":
                        print(f"  [FIX ] scalar socket '{sock_name}': redirecting Alpha → Color")
                        blender_out = "Color"
                    safe_link(links,
                              resolve_output(src_bn, blender_out),
                              p_node.inputs.get(sock_name),
                              label=f"{src_node_id}.{blender_out} -> Principled.{sock_name}")

            # ── Transmission / transparency flags ─────────────────────
            # In Blender, a Principled BSDF with Transmission Weight > 0
            # will be invisible in renders unless the material is told it
            # can be transparent.  Two settings are required:
            #
            #  1. mat.blend_method = 'HASHED'
            #     Tells the rasteriser (and Cycles viewport) to treat the
            #     surface as potentially transparent.  'HASHED' avoids
            #     sorting artefacts that 'BLEND' can produce.
            #
            #  2. mat.use_screen_refraction = True  (Blender < 4.2)
            #     Enables screen-space refraction in the viewport.
            #     In Blender 4.2+ this flag was removed; Cycles handles
            #     refraction automatically once blend_method is correct.
            #
            # We read the transmission value from the Principled BSDF
            # socket rather than the raw JSON so the check works whether
            # the value came from a direct scalar or a texture connection.
            transmission_sock = p_node.inputs.get("Transmission Weight")
            has_transmission = False
            if transmission_sock is not None:
                if transmission_sock.links:          # driven by a texture
                    has_transmission = True
                elif float(transmission_sock.default_value) > 0.0:
                    has_transmission = True

            if has_transmission:
                try:
                    mat.blend_method = "HASHED"
                    print(f"  [MAT ] blend_method = HASHED  (transmission present)")
                except Exception:
                    pass
                try:
                    mat.use_screen_refraction = True
                    print(f"  [MAT ] use_screen_refraction = True")
                except Exception:
                    pass  # Blender 4.2+ removed this property — safe to ignore

            obj.data.materials.append(mat)
            layout_nodes(mat.node_tree, out_node)
            print(f"  [DONE] '{shader_name}'")

    # ── Lights ────────────────────────────────────────────────────────────
    if lights_data:
        print("\n" + "─"*60)
        print("[LIGHTS] {} lights".format(len(lights_data)))
        print("─"*60)
        for light_name, light_data in lights_data.items():
            b_type = light_data.get("blenderType")
            print("\n[LIGHT] '{}' → {}".format(light_name, b_type))
            try:
                if b_type == "WORLD":
                    import_skydome(light_data)
                    continue
                obj, light, is_new = get_or_create_light(light_name, b_type)
                print("  {} '{}'".format("Created" if is_new else "Found existing", light_name))
                if is_new:
                    tf = light_data.get("transform", {})
                    t  = tf.get("translate", [0, 0, 0])
                    r  = tf.get("rotate",    [0, 0, 0])
                    obj.location       = yup_to_zup_location(t)
                    obj.rotation_euler = yup_to_zup_rotation(r)
                    print("  Transform applied (Y-up → Z-up)")
                if   b_type == "POINT": import_point(light, light_data)
                elif b_type == "SUN":   import_sun(light, light_data)
                elif b_type == "SPOT":  import_spot(light, light_data)
                elif b_type == "AREA":  import_area(light, light_data, is_new)
            except Exception as e:
                print("  [ERROR] '{}': {}".format(light_name, e))

    print(f"\n{'='*60}")
    print("[IMPORT] Complete.")
    print('='*60)

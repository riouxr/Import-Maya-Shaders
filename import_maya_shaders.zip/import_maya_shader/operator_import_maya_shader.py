import os
import bpy
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty
from bpy.types import Operator
from . import import_maya_shader


def _collect_all_objects(collection, found=None):
    """Recursively gather all objects from a collection and its children."""
    if found is None:
        found = set()
    for obj in collection.objects:
        found.add(obj.name)
    for child in collection.children:
        _collect_all_objects(child, found)
    return found


def _remove_collection_tree(collection):
    """Recursively unlink and delete a collection hierarchy (used for
    the temporary collection Alembic creates on import)."""
    for child in list(collection.children):
        _remove_collection_tree(child)
    # Only remove if it is no longer a child of any collection
    bpy.data.collections.remove(collection, do_unlink=True)


class IMPORT_OT_Import_Maya_Shader(Operator, ImportHelper):
    """Import a Maya to Blender export: picks the JSON file, then shows
    an options dialog before the heavy Alembic import begins."""
    bl_idname  = "import.maya_shader"
    bl_label   = "Maya Scene (.abc + .json)"

    filename_ext = ".json"
    filter_glob: StringProperty(
        default="*.json",
        options={"HIDDEN"},
        maxlen=255,
    )

    def execute(self, context):
        # Validate paths before opening the options dialog so the user gets
        # an error immediately if something is wrong.
        json_path = self.filepath
        if not os.path.isfile(json_path):
            self.report({"ERROR"}, "JSON not found: " + json_path)
            return {"CANCELLED"}
        abc_path = os.path.splitext(json_path)[0] + ".abc"
        if not os.path.isfile(abc_path):
            self.report({"ERROR"}, "Paired .abc not found: " + abc_path)
            return {"CANCELLED"}

        # Hand off to the options dialog, passing the validated paths.
        bpy.ops.wm.maya_shader_run(
            "INVOKE_DEFAULT",
            json_path=json_path,
            abc_path=abc_path,
        )
        return {"FINISHED"}


class IMPORT_OT_Maya_Shader_Run(Operator):
    """Options popup shown after file selection, before the heavy import.
    Keeping this separate means the dialog is always visible and responsive,
    even when the scene file is large."""
    bl_idname  = "wm.maya_shader_run"
    bl_label   = "Maya Import Options"
    bl_options = {"REGISTER", "UNDO"}

    json_path: StringProperty(options={"HIDDEN"})
    abc_path:  StringProperty(options={"HIDDEN"})

    apply_subdivision: BoolProperty(
        name="Apply Subdivision",
        description=(
            "Add a Subdivision Surface modifier (viewport off, render on) "
            "to meshes that were in smooth-preview mode (key 3) in Maya"
        ),
        default=True,
    )

    def invoke(self, context, event):
        # Show a clean popup dialog — user confirms options before any
        # heavy work starts, so the UI is fully responsive at this point.
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        self.layout.prop(self, "apply_subdivision")

    def execute(self, context):
        json_path = self.json_path
        abc_path  = self.abc_path

        # ── 1. Import Alembic ─────────────────────────────────────────────
        self.report({"INFO"}, "Importing Alembic: " + abc_path)
        scene_root         = bpy.context.scene.collection
        collections_before = set(bpy.data.collections.keys())
        objects_before     = set(bpy.data.objects.keys())

        # Force the active layer collection to Scene Collection root so that
        # Blender's Alembic importer always lands in the scene root, regardless
        # of what the user has selected in the outliner.
        context.view_layer.active_layer_collection = context.view_layer.layer_collection

        try:
            result = bpy.ops.wm.alembic_import(
                "EXEC_DEFAULT",
                filepath=abc_path,
                scale=1.0,
                set_frame_range=True,
                is_sequence=False,
            )
            if "FINISHED" not in result:
                self.report({"ERROR"}, "Alembic import returned: " + str(result))
                return {"CANCELLED"}
        except Exception as e:
            self.report({"ERROR"}, "Alembic import failed: " + str(e))
            return {"CANCELLED"}

        bpy.context.view_layer.update()

        # Alembic may create its own collection(s) to hold imported objects.
        # Collect all newly imported object names from those collections,
        # then move every one of them directly to Scene Collection root,
        # and delete the temporary Alembic collections.
        new_collections = [
            bpy.data.collections[n]
            for n in set(bpy.data.collections.keys()) - collections_before
            if n in bpy.data.collections
        ]

        new_obj_names = (set(bpy.data.objects.keys()) - objects_before)

        # Also pick up any objects that landed in new Alembic collections
        for col in new_collections:
            new_obj_names |= _collect_all_objects(col)

        # Move all new objects to Scene Collection root
        for obj_name in new_obj_names:
            obj = bpy.data.objects.get(obj_name)
            if obj is None:
                continue
            for col in list(obj.users_collection):
                col.objects.unlink(obj)
            scene_root.objects.link(obj)

        # Remove the now-empty temporary Alembic collections
        for col in new_collections:
            try:
                _remove_collection_tree(col)
            except Exception:
                pass  # already gone or still has other users — skip

        bpy.context.view_layer.update()

        # ── 2. Apply shaders & lights from JSON ───────────────────────────
        self.report({"INFO"}, "Applying shaders from JSON: " + json_path)
        import_maya_shader.import_ai_standard_surface_data(
            json_path, apply_subdivision=self.apply_subdivision
        )

        self.report({"INFO"}, "Maya scene import complete.")
        return {"FINISHED"}


def menu_func_import(self, context):
    self.layout.operator(
        IMPORT_OT_Import_Maya_Shader.bl_idname,
        text="Maya Scene (.abc + .json)",
    )


classes = [IMPORT_OT_Import_Maya_Shader, IMPORT_OT_Maya_Shader_Run]
menus   = [menu_func_import]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    for menu in menus:
        bpy.types.TOPBAR_MT_file_import.append(menu)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    for menu in menus:
        bpy.types.TOPBAR_MT_file_import.remove(menu)


if __name__ == "__main__":
    register()
